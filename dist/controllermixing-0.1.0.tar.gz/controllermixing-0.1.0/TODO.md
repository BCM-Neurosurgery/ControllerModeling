1. Make bayes slack model
2. Make hierarchical switch
3. Swap RNN/MLP/KAN for basis (can all jax-ifyed), and multi-trial training.